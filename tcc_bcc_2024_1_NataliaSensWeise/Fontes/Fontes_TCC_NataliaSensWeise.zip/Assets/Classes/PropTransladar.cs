﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PropTransladar : MonoBehaviour {

    private string nome;
    private float x;
    private float y;
    private float z;
    private bool ativo;

    public string Nome { get; set; }
    public float X { get; set; }
    public float Y { get; set; }
    public float Z { get; set; }
    public bool Ativo { get; set; }

    public PropTransladar()
    {

    }
}
