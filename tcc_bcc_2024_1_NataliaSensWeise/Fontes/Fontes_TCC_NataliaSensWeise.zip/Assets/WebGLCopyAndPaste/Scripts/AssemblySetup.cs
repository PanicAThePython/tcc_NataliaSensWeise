#if UNITY_WEBGL && UNITY_2018_3_OR_NEWER
using UnityEngine.Scripting;

[assembly: AlwaysLinkAssembly]
#endif
