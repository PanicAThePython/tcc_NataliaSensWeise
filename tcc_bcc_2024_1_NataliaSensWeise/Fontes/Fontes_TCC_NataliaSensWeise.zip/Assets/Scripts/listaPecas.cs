﻿using System.Collections.Generic;

internal class listaPecas<T> : List<string>
{
}